"use strict";
// StockLens AI 3.0 — single-page client. All DOM is built with textContent/createElement (no innerHTML with data).

// ---------- tiny helpers ----------
const $ = (sel, root = document) => root.querySelector(sel);
const SYMBOL_RE = /^[A-Z0-9.^-]{1,20}$/;

function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === "class") el.className = v;
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v === true ? "" : v);
  }
  for (const kid of kids.flat()) {
    if (kid === null || kid === undefined || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return el;
}
// Like el.replaceChildren but skips null/false and flattens arrays (the native method would stringify them).
function put(el, ...kids) {
  el.replaceChildren(...kids.flat(Infinity).filter((k) => k !== null && k !== undefined && k !== false).map((k) => (k.nodeType ? k : document.createTextNode(String(k)))));
  return el;
}
const svgEl = (tag, attrs) => {
  const el = document.createElementNS("http://www.w3.org/2000/svg", tag);
  for (const [k, v] of Object.entries(attrs || {})) el.setAttribute(k, v);
  return el;
};

const ICONS = {
  logo: "M3 17l5-5 4 4 8-9M15 7h5v5",
  home: "M3 11l9-8 9 8M5 10v10h14V10",
  star: "M12 3l2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.2 6.5 20.2l1-6.2L3 9.6l6.2-.9z",
  sparkles: "M12 3l1.8 4.7L18.5 9.5l-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8zM19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z",
  search: "M11 19a8 8 0 100-16 8 8 0 000 16zM21 21l-4.3-4.3",
  contrast: "M12 21a9 9 0 100-18 9 9 0 000 18zM12 3v18",
  bell: "M6 9a6 6 0 1112 0c0 6 2 7 2 7H4s2-1 2-7M10 20a2 2 0 004 0",
  plus: "M12 5v14M5 12h14",
  scale: "M12 3v18M5 7h14M5 7l-3 7a4 4 0 006 0zM19 7l-3 7a4 4 0 006 0z",
  refresh: "M20 11a8 8 0 10-2.3 5.7M20 4v7h-7",
  download: "M12 3v12m0 0l-4-4m4 4l4-4M4 21h16",
  stop: "M7 7h10v10H7z"
};
function icon(name) {
  const s = svgEl("svg", { class: "ic", viewBox: "0 0 24 24", "aria-hidden": "true" });
  s.append(svgEl("path", { d: ICONS[name] || "" }));
  return s;
}
function hydrateIcons(root = document) {
  root.querySelectorAll("[data-icon]").forEach((el) => { put(el, icon(el.dataset.icon)); el.removeAttribute("data-icon"); });
}

const valid = (v) => typeof v === "number" && Number.isFinite(v);
const fmtNum = (v, d = 2) => (valid(Number(v)) && v !== null && v !== "" ? Number(v).toLocaleString("en-US", { maximumFractionDigits: d }) : "—");
const fmtPct = (v, d = 2) => (v === null || v === undefined || !valid(Number(v)) ? "—" : `${v > 0 ? "+" : ""}${Number(v).toFixed(d)}%`);
const fmtPlain = (v, suffix = "", d = 2) => (v === null || v === undefined || !valid(Number(v)) ? "—" : `${Number(v).toFixed(d)}${suffix}`);
function fmtMoney(v, cur = "USD") {
  if (v === null || v === undefined || !valid(Number(v))) return "—";
  try { return new Intl.NumberFormat("en-US", { style: "currency", currency: cur || "USD" }).format(v); } catch { return fmtNum(v); }
}
const fmtCap = (m) => (m === null || m === undefined ? "—" : m >= 1e6 ? `${(m / 1e6).toFixed(2)}T` : m >= 1e3 ? `${(m / 1e3).toFixed(1)}B` : `${m.toFixed(0)}M`);
const dir = (v) => (v > 0 ? "up" : v < 0 ? "down" : "flat");
const fmtDate = (ms) => new Date(ms).toLocaleDateString("th-TH-u-ca-gregory", { day: "numeric", month: "short", year: "2-digit" });
function ago(ms) {
  const m = Math.max(0, Math.round((Date.now() - ms) / 60000));
  if (m < 60) return `${m || 1} นาทีที่แล้ว`;
  if (m < 1440) return `${Math.round(m / 60)} ชม.ที่แล้ว`;
  return `${Math.round(m / 1440)} วันที่แล้ว`;
}
const safeUrl = (u) => { try { const x = new URL(u); return x.protocol === "https:" || x.protocol === "http:" ? x.href : null; } catch { return null; } };
const sanitize = (s) => String(s || "").trim().toUpperCase().replace(/\s+/g, "");

let toastTimer;
function toast(msg) {
  const el = $("#toast");
  el.textContent = msg; el.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove("show"), 3500);
}

const store = {
  get(key, fallback) { try { const v = JSON.parse(localStorage.getItem(key)); return v ?? fallback; } catch { return fallback; } },
  set(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch { toast("เบราว์เซอร์ไม่อนุญาตให้บันทึกข้อมูล"); } }
};

async function api(url, options) {
  let response;
  try { response = await fetch(url, options); }
  catch { throw Object.assign(new Error("เชื่อมต่อเซิร์ฟเวอร์ไม่ได้ ตรวจสอบอินเทอร์เน็ต"), { code: "network" }); }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw Object.assign(new Error(data.error || `เกิดข้อผิดพลาด (${response.status})`), { code: data.code, status: response.status });
  return data;
}

const errorBox = (message, retry) => h("div", { class: "err-box" }, h("span", {}, message), retry && h("button", { class: "btn", onclick: retry }, "ลองอีกครั้ง"));

// ---------- persisted state ----------
let watchlist = store.get("sl3-watch", null) ?? store.get("stocklens-watchlist", []);
let compare = store.get("sl3-compare", []);
let alerts = store.get("sl3-alerts", null) ?? store.get("stocklens-alerts", []).map((a) => ({ id: crypto.randomUUID(), symbol: a.symbol, dir: a.direction === "below" ? "below" : "above", target: a.target, triggered: Boolean(a.triggered) }));
const saveWatch = () => store.set("sl3-watch", watchlist);
const saveCompare = () => store.set("sl3-compare", compare);
const saveAlerts = () => store.set("sl3-alerts", alerts);

let health = { finnhub: false, gemini: false };
let ctxSymbol = "";
let timers = [];
const every = (ms, fn) => timers.push(setInterval(() => { if (!document.hidden) fn(); }, ms));

// ---------- theme ----------
(function initTheme() {
  const saved = store.get("sl3-theme", null);
  const light = saved ? saved === "light" : matchMedia("(prefers-color-scheme: light)").matches;
  document.documentElement.dataset.theme = light ? "light" : "dark";
  $("#theme").addEventListener("click", () => {
    const next = document.documentElement.dataset.theme === "light" ? "dark" : "light";
    document.documentElement.dataset.theme = next; store.set("sl3-theme", next);
  });
})();

// ---------- sidebar status ----------
function renderStatus() {
  const row = (label, on) => h("div", {}, h("span", { class: "dot " + (on ? "on" : "off") }), `${label}: ${on ? "เชื่อมต่อแล้ว" : "ยังไม่ตั้งค่า"}`);
  put($("#status"), 
    row("Finnhub", health.finnhub), row("Gemini", health.gemini),
    (!health.finnhub || !health.gemini) && h("small", {}, "ตั้งค่า API Key ใน Environment ของเซิร์ฟเวอร์")
  );
}

// ---------- search ----------
const qInput = $("#q"), suggestBox = $("#suggest");
let suggestItems = [], suggestSel = -1, suggestFor = "", searchSeq = 0, searchTimer;
const go = (symbol) => { hideSuggest(); qInput.value = ""; qInput.blur(); location.hash = `#/stock/${encodeURIComponent(symbol)}`; };
function hideSuggest() { suggestBox.hidden = true; suggestItems = []; suggestSel = -1; }
function showSuggest(results, error, forQuery = "") {
  suggestItems = results; suggestSel = -1; suggestFor = forQuery;
  put(suggestBox, 
    ...(results.length
      ? results.map((r) => h("button", { type: "button", role: "option", onmousedown: (e) => { e.preventDefault(); go(r.symbol); } },
        h("span", {}, h("strong", {}, r.symbol), " ", h("small", {}, r.description)), h("small", {}, r.type)))
      : [h("div", { class: "empty" }, error || "ไม่พบผลลัพธ์ ลองพิมพ์ Ticker โดยตรง แล้วกด Enter")])
  );
  suggestBox.hidden = false;
}
qInput.addEventListener("input", () => {
  clearTimeout(searchTimer);
  const v = qInput.value.trim();
  if (!v) return hideSuggest();
  searchTimer = setTimeout(async () => {
    const mine = ++searchSeq;
    try { const d = await api(`/api/search?q=${encodeURIComponent(v)}`); if (mine === searchSeq) showSuggest(d.results, "", v); }
    catch (e) { if (mine === searchSeq) showSuggest([], e.message); }
  }, 250);
});
qInput.addEventListener("keydown", (e) => {
  if (e.key === "Escape") return hideSuggest();
  if ((e.key === "ArrowDown" || e.key === "ArrowUp") && suggestItems.length) {
    e.preventDefault();
    suggestSel = (suggestSel + (e.key === "ArrowDown" ? 1 : -1) + suggestItems.length) % suggestItems.length;
    [...suggestBox.children].forEach((c, i) => c.classList.toggle("sel", i === suggestSel));
  }
});
qInput.addEventListener("blur", () => setTimeout(hideSuggest, 120));
$("#search-form").addEventListener("submit", (e) => {
  e.preventDefault();
  const typed = sanitize(qInput.value);
  if (suggestSel >= 0) return go(suggestItems[suggestSel].symbol);
  const fresh = suggestFor === qInput.value.trim() && suggestItems.length;   // results match what is typed now
  if (fresh) return go((suggestItems.find((r) => r.symbol.toUpperCase() === typed) || suggestItems[0]).symbol);
  if (SYMBOL_RE.test(typed)) return go(typed);
  toast("พิมพ์ Ticker หรือชื่อบริษัทที่ต้องการค้นหา");
});
document.addEventListener("keydown", (e) => {
  if (e.key === "/" && !/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName)) { e.preventDefault(); qInput.focus(); }
});

// ---------- shared components ----------
function rangeBar(label, low, high, value) {
  const ok = valid(low) && valid(high) && high > low && valid(value);
  const pct = ok ? Math.min(100, Math.max(0, ((value - low) / (high - low)) * 100)) : 0;
  const marker = h("i", { class: "marker" });
  marker.style.left = pct + "%";
  return h("div", { class: "range" },
    h("div", { class: "muted" }, label),
    h("div", { class: "track" }, ok && marker),
    h("div", { class: "labels" }, h("span", {}, fmtNum(low)), h("span", {}, fmtNum(high))));
}
const newsList = (items) => h("div", { class: "news-list" }, items.map((n) => {
  const href = safeUrl(n.url);
  return h("a", { href: href || "#", target: "_blank", rel: "noopener noreferrer" },
    h("strong", {}, n.headline), h("small", {}, [n.source, n.time ? ago(n.time) : ""].filter(Boolean).join(" · ")));
}));

function toggleWatch(symbol) {
  if (watchlist.includes(symbol)) watchlist = watchlist.filter((s) => s !== symbol);
  else if (watchlist.length >= 20) return toast("ติดตามได้สูงสุด 20 หุ้น");
  else watchlist = [...watchlist, symbol];
  saveWatch(); return watchlist.includes(symbol);
}
function addCompare(symbol) {
  if (compare.includes(symbol)) return toast(`${symbol} อยู่ในรายการเปรียบเทียบแล้ว`);
  if (compare.length >= 3) return toast("เปรียบเทียบได้สูงสุด 3 หุ้น (ลบออกในหน้าติดตามก่อน)");
  compare = [...compare, symbol]; saveCompare(); toast(`เพิ่ม ${symbol} เข้าการเปรียบเทียบแล้ว ดูได้ที่หน้า "ติดตาม"`);
}
function createAlert(symbol, direction, target) {
  if (!SYMBOL_RE.test(symbol) || !(target > 0)) return toast("กรอก Ticker และราคาเป้าหมายให้ถูกต้อง"), false;
  if (alerts.length >= 20) return toast("ตั้งแจ้งเตือนได้สูงสุด 20 รายการ"), false;
  alerts = [...alerts, { id: crypto.randomUUID(), symbol, dir: direction, target, triggered: false }]; saveAlerts();
  toast(`ตั้งแจ้งเตือน ${symbol} แล้ว`); return true;
}

// ---------- router ----------
const views = { market: renderMarket, stock: renderStock, watchlist: renderWatchlist, copilot: renderCopilot };
function route() {
  const [name = "", arg = ""] = location.hash.replace(/^#\/?/, "").split("/");
  const view = views[name] ? name : "market";
  timers.forEach(clearInterval); timers = [];
  document.querySelectorAll(".view").forEach((v) => (v.hidden = v.id !== `view-${view}`));
  document.querySelectorAll("[data-nav]").forEach((a) => a.classList.toggle("active", a.dataset.nav === view));
  window.scrollTo(0, 0);
  let sym = ""; try { sym = sanitize(decodeURIComponent(arg)); } catch { /* malformed URL */ }
  views[view](sym);
}
window.addEventListener("hashchange", route);

// ---------- market view ----------
const POPULAR = ["AAPL", "MSFT", "NVDA", "GOOGL", "AMZN", "META", "TSLA"];
function renderMarket() {
  const root = $("#view-market");
  const status = h("span", { class: "pill" }, "กำลังตรวจสอบสถานะตลาด…");
  const indices = h("div", { class: "grid4" });
  const news = h("div", {}, h("p", { class: "loading" }, "กำลังโหลดข่าว…"));
  put(root, 
    h("div", { class: "page-title" }, h("h1", {}, "ภาพรวมตลาดสหรัฐ"), status),
    h("div", { class: "stack" },
      indices,
      h("div", { class: "card" }, h("h3", {}, "หุ้นยอดนิยม"), h("div", { class: "chips" }, POPULAR.map((s) => h("a", { class: "chip", href: `#/stock/${s}` }, s)))),
      h("div", { class: "card" }, h("h3", {}, "ข่าวตลาดล่าสุด"), news))
  );
  async function load() {
    try {
      const d = await api("/api/market");
      put(status, h("span", { class: "dot " + (d.status?.isOpen ? "on" : "") }), d.status ? (d.status.isOpen ? "ตลาดเปิด" : d.status.holiday ? `ตลาดปิด · ${d.status.holiday}` : "ตลาดปิด") : "ไม่ทราบสถานะตลาด");
      put(indices, ...d.indices.map((i) => h("a", { class: "card index-card", href: `#/stock/${i.symbol}` },
        h("small", {}, `${i.name} · ${i.symbol}`),
        h("span", { class: "big num" }, i.quote ? fmtNum(i.quote.price) : "—"),
        h("span", { class: "num " + dir(i.quote?.change) }, i.quote ? fmtPct(i.quote.changePercent) : "ไม่มีข้อมูล"))));
      put(news, d.news.length ? newsList(d.news) : h("p", { class: "empty-note" }, "ไม่มีข่าวในขณะนี้"));
    } catch (e) {
      status.textContent = "โหลดข้อมูลไม่สำเร็จ";
      put(indices, h("div", { class: "span-all" }, errorBox(e.message, load)));
      put(news);
    }
  }
  load(); every(60_000, load);
}

// ---------- stock view ----------
let currentStock = null;
async function renderStock(symbol) {
  const root = $("#view-stock");
  if (!SYMBOL_RE.test(symbol)) { location.hash = "#/"; return; }
  ctxSymbol = symbol;
  put(root, h("p", { class: "loading" }, `กำลังโหลดข้อมูล ${symbol}…`));
  let d;
  try { d = await api(`/api/stock/${encodeURIComponent(symbol)}`); }
  catch (e) { if (ctxSymbol === symbol) put(root, errorBox(e.message, () => renderStock(symbol))); return; }
  if (ctxSymbol !== symbol || !$("#view-stock") || $("#view-stock").hidden) return;
  currentStock = d;
  const cur = d.profile?.currency || "USD";
  const q = d.quote, m = d.metrics || {};

  // header
  const watchBtn = h("button", { class: "btn", type: "button" });
  const setWatchLabel = () => { const on = watchlist.includes(symbol); watchBtn.classList.toggle("on", on); put(watchBtn, icon("star"), on ? "ติดตามแล้ว" : "ติดตาม"); };
  watchBtn.addEventListener("click", () => { toggleWatch(symbol); setWatchLabel(); });
  setWatchLabel();
  const alertPrice = h("input", { class: "field", type: "number", step: "any", min: "0", placeholder: "ราคาเป้าหมาย", value: q ? q.price : "", "aria-label": "ราคาเป้าหมาย" });
  const alertDir = h("select", { class: "field", "aria-label": "เงื่อนไข" }, h("option", { value: "above" }, "ราคา ≥"), h("option", { value: "below" }, "ราคา ≤"));
  const alertForm = h("form", { class: "alert-inline row-form", hidden: true, onsubmit: (e) => { e.preventDefault(); if (createAlert(symbol, alertDir.value, Number(alertPrice.value))) alertForm.hidden = true; } },
    alertDir, alertPrice, h("button", { class: "btn primary", type: "submit" }, "บันทึกแจ้งเตือน"));

  const header = h("section", { class: "card head" },
    h("div", { class: "ident" },
      d.profile?.logo && h("img", { class: "logo", src: d.profile.logo, alt: "", referrerpolicy: "no-referrer", onerror: (e) => e.target.remove() }),
      h("div", {}, h("h1", {}, d.profile?.name || symbol), h("p", { class: "muted" }, [symbol, d.profile?.exchange, d.profile?.industry, d.profile?.country].filter(Boolean).join(" · ")))),
    h("div", { class: "quote" },
      h("div", { class: "price" }, fmtMoney(q?.price, cur)),
      h("div", { class: "chg " + dir(q?.change) }, q ? `${q.change > 0 ? "+" : ""}${fmtNum(q.change)} (${fmtPct(q.changePercent)})` : "ไม่มีข้อมูลราคา")),
    h("div", { class: "actions" },
      watchBtn,
      h("button", { class: "btn", type: "button", onclick: () => addCompare(symbol) }, icon("scale"), "เปรียบเทียบ"),
      h("button", { class: "btn", type: "button", onclick: () => { alertForm.hidden = !alertForm.hidden; } }, icon("bell"), "แจ้งเตือนราคา"),
      h("a", { class: "btn", href: "#/copilot", onclick: () => { ctxSymbol = symbol; } }, icon("sparkles"), "ถาม Co-Pilot")),
    alertForm);

  // range bars
  const ranges = h("section", { class: "card range-pair" },
    rangeBar("ช่วงราคาวันนี้", q?.low, q?.high, q?.price),
    rangeBar("ช่วงราคา 52 สัปดาห์", m["52WeekLow"], m["52WeekHigh"], q?.price));

  // chart
  const chartHost = h("div", { class: "chart-wrap" });
  const chartFoot = h("div", { class: "chart-foot" });
  let candles = [], days = 90;
  const tabs = [["1M", 30], ["3M", 90], ["6M", 180], ["1Y", 365]].map(([label, n]) =>
    h("button", { type: "button", class: n === days ? "on" : "", onclick: (e) => { days = n; tabs.forEach((b) => b.classList.toggle("on", b === e.currentTarget)); loadChart(); } }, label));
  const csvBtn = h("button", { class: "btn small", type: "button", disabled: true, onclick: () => exportCsv(symbol, candles) }, icon("download"), "CSV");
  async function loadChart() {
    put(chartHost, h("div", { class: "chart-note" }, "กำลังโหลดกราฟ…")); put(chartFoot); csvBtn.disabled = true;
    try {
      candles = (await api(`/api/candles/${encodeURIComponent(symbol)}?days=${days}`)).candles;
      if (ctxSymbol !== symbol) return;
      if (candles.length < 2) throw new Error("ข้อมูลไม่เพียงพอสำหรับวาดกราฟ");
      put(chartHost, lineChart(candles, cur, chartHost.clientWidth));
      const first = candles[0].close, last = candles.at(-1).close;
      put(chartFoot, h("span", {}, `${candles.length} วันซื้อขาย`), h("span", { class: "num " + dir(last - first) }, `${fmtPct((last / first - 1) * 100)} ในช่วงนี้`));
      csvBtn.disabled = false;
    } catch (e) {
      put(chartHost, h("div", { class: "chart-note" },
        h("strong", {}, e.code === "plan" ? "กราฟย้อนหลังไม่รองรับในแผน Finnhub ปัจจุบัน" : "โหลดกราฟไม่สำเร็จ"),
        h("span", {}, e.code === "plan" ? "ข้อมูลราคาย้อนหลังต้องใช้แผนแบบชำระเงิน คุณยังดูช่วงราคา 52 สัปดาห์ด้านบนได้" : e.message)));
    }
  }
  const chartCard = h("section", { class: "card" },
    h("div", { class: "card-title" }, "ราคาปิดรายวัน", h("span", { class: "row-form" }, h("span", { class: "seg" }, tabs), csvBtn)), chartHost, chartFoot);

  // AI analysis
  const aiOut = h("div", { class: "ai-body" });
  const aiBtn = h("button", { class: "btn primary", type: "button", disabled: !health.gemini }, icon("sparkles"), "สร้างบทวิเคราะห์ด้วย Gemini");
  aiBtn.addEventListener("click", async () => {
    aiBtn.disabled = true; put(aiOut, h("p", { class: "loading" }, "Gemini กำลังวิเคราะห์ข้อมูลจริงของหุ้นนี้…"));
    try { renderAnalysis(aiOut, await api("/api/ai/analyze", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ symbol }) })); }
    catch (e) { put(aiOut, errorBox(e.message)); }
    finally { aiBtn.disabled = false; aiBtn.lastChild.textContent = "สร้างใหม่"; }
  });
  const aiCard = h("section", { class: "card" },
    h("div", { class: "card-title" }, "บทวิเคราะห์โดย AI", aiBtn),
    health.gemini ? aiOut : h("p", { class: "empty-note" }, "ยังไม่ได้ตั้งค่า GEMINI_API_KEY บนเซิร์ฟเวอร์"));
  if (health.gemini) aiOut.append(h("p", { class: "muted" }, "กดปุ่มเพื่อให้ Gemini สรุปจุดแข็ง ความเสี่ยง มูลค่า และข่าวล่าสุด โดยอ้างอิงเฉพาะข้อมูลที่ดึงจาก Finnhub"));

  // signals
  const signalsCard = d.signals.length ? h("section", { class: "card" },
    h("div", { class: "card-title" }, "สัญญาณจากตัวชี้วัด", h("small", {}, "คำนวณด้วยกฎ ไม่ใช่ AI")),
    d.signals.map((s) => h("div", { class: "signal" }, h("span", { class: `dot ${s.tone}` }), h("span", {}, s.text)))) : null;

  // news
  const newsCard = h("section", { class: "card" }, h("h3", {}, "ข่าวบริษัท 7 วันล่าสุด"),
    d.news.length ? newsList(d.news) : h("p", { class: "empty-note" }, d.failed.news ? "โหลดข่าวไม่สำเร็จ" : "ไม่มีข่าวในช่วงนี้"));

  // side column
  const kv = (label, value) => h("div", {}, h("span", {}, label), h("strong", {}, value));
  const metricsCard = h("section", { class: "card kv" }, h("h3", {}, "ตัวชี้วัดหลัก"),
    h("h4", {}, "มูลค่า"), kv("Market Cap", d.profile ? `${fmtCap(d.profile.marketCapMillions)} ${cur}` : "—"), kv("P/E (TTM)", fmtPlain(m.peTTM, "x")), kv("P/B", fmtPlain(m.pbQuarterly, "x")), kv("P/S", fmtPlain(m.psTTM, "x")), kv("EPS (TTM)", fmtNum(m.epsTTM)), kv("ปันผลต่อปี", fmtPlain(m.dividendYieldIndicatedAnnual, "%")),
    h("h4", {}, "ความสามารถทำกำไร"), kv("ROE", fmtPlain(m.roeTTM, "%")), kv("ROA", fmtPlain(m.roaTTM, "%")), kv("Gross margin", fmtPlain(m.grossMarginTTM, "%")), kv("Operating margin", fmtPlain(m.operatingMarginTTM, "%")), kv("Net margin", fmtPlain(m.netProfitMarginTTM, "%")),
    h("h4", {}, "การเติบโต"), kv("รายได้ YoY", fmtPlain(m.revenueGrowthTTMYoy, "%")), kv("EPS YoY", fmtPlain(m.epsGrowthTTMYoy, "%")),
    h("h4", {}, "ความเสี่ยง"), kv("Beta", fmtPlain(m.beta)), kv("หนี้สินต่อทุน (D/E)", fmtPlain(m["totalDebt/totalEquityQuarterly"])), kv("Current ratio", fmtPlain(m.currentRatioQuarterly)));
  if (d.failed.metrics) metricsCard.append(h("p", { class: "disc" }, "โหลดตัวชี้วัดบางส่วนไม่สำเร็จ"));

  let analystCard = null;
  if (d.recommendation) {
    const r = d.recommendation;
    const parts = [["s1", "Strong Buy", r.strongBuy], ["s2", "Buy", r.buy], ["s3", "Hold", r.hold], ["s4", "Sell", r.sell], ["s5", "Strong Sell", r.strongSell]];
    analystCard = h("section", { class: "card" }, h("div", { class: "card-title" }, "ความเห็นนักวิเคราะห์", h("small", {}, r.period)),
      h("div", { class: "rec-bar", role: "img", "aria-label": parts.map(([, l, n]) => `${l} ${n}`).join(", ") }, parts.map(([c, , n]) => { const i = h("i", { class: c }); i.style.flexGrow = String(n || 0); return n ? i : null; })),
      h("div", { class: "legend" }, parts.map(([c, l, n]) => h("span", {}, h("i", { class: c }), `${l} ${n ?? 0}`))));
  }

  let earnCard = null;
  if (d.earnings.length || d.nextEarnings) {
    earnCard = h("section", { class: "card" }, h("div", { class: "card-title" }, "ผลประกอบการ (EPS)", d.nextEarnings && h("small", {}, `ประกาศถัดไป ${d.nextEarnings.date}`)),
      d.earnings.length ? h("div", { class: "tbl-scroll" }, h("table", { class: "t" },
        h("thead", {}, h("tr", {}, h("th", {}, "งวด"), h("th", {}, "จริง"), h("th", {}, "คาดการณ์"), h("th", {}, "ผลต่าง"))),
        h("tbody", {}, d.earnings.map((e) => h("tr", {}, h("td", {}, e.period), h("td", {}, fmtNum(e.actual)), h("td", {}, fmtNum(e.estimate)), h("td", { class: dir(e.surprisePercent) }, fmtPct(e.surprisePercent, 1))))))) : h("p", { class: "empty-note" }, "ยังไม่มีข้อมูลผลประกอบการ"));
  }
  const peersCard = d.peers.length ? h("section", { class: "card" }, h("h3", {}, "บริษัทคู่เทียบ"), h("div", { class: "chips" }, d.peers.map((p) => h("a", { class: "chip", href: `#/stock/${encodeURIComponent(p)}` }, p)))) : null;

  put(root, h("div", { class: "stack" }, header, ranges,
    h("div", { class: "cols" }, h("div", { class: "stack" }, chartCard, aiCard, signalsCard, newsCard), h("div", { class: "stack" }, metricsCard, analystCard, earnCard, peersCard)),
    h("p", { class: "disc" }, `ข้อมูลจาก Finnhub · อัปเดต ${new Date(d.asOf).toLocaleTimeString("th-TH")} · ราคาอาจล่าช้าและความครอบคลุมขึ้นกับแผน API`)));
  loadChart();
}

function renderAnalysis(host, data) {
  const a = data.analysis;
  const list = (title, items, cls) => items?.length ? h("div", { class: `ai-box ${cls || ""}` }, h("h4", {}, title), h("ul", { class: "tidy" }, items.map((t) => h("li", {}, t)))) : null;
  put(host, 
    h("p", {}, a.summary),
    h("div", { class: "ai-cols" }, list("จุดแข็ง", a.strengths, "good"), list("ความเสี่ยง", a.risks, "bad")),
    a.valuation && h("div", { class: "ai-box" }, h("h4", {}, "มุมมองด้านมูลค่า"), h("p", {}, a.valuation)),
    list("ธีมจากข่าวล่าสุด", a.newsThemes), list("สิ่งที่ควรติดตามต่อ", a.watch),
    h("p", { class: "disc" }, `สร้างโดย ${data.model}${data.cached ? " (ผลที่แคชไว้ไม่เกิน 15 นาที)" : ""} · AI อาจผิดพลาด ไม่ใช่คำแนะนำการลงทุน`));
}

function lineChart(candles, cur, width) {
  const W = Math.max(300, Math.round(width || 900)), H = W < 520 ? 220 : 300, P = { t: 14, r: 12, b: 26, l: 58 };
  const vals = candles.map((c) => c.close);
  const lo = Math.min(...vals), hi = Math.max(...vals), span = hi - lo || Math.max(1, hi * 0.02);
  const min = lo - span * 0.06, max = hi + span * 0.06, rng = max - min;
  const x = (i) => P.l + (i * (W - P.l - P.r)) / Math.max(1, vals.length - 1);
  const y = (v) => P.t + ((max - v) * (H - P.t - P.b)) / rng;
  const svg = svgEl("svg", { viewBox: `0 0 ${W} ${H}`, class: "chart " + (vals.at(-1) >= vals[0] ? "up" : "down"), role: "img", "aria-label": "กราฟราคาปิดรายวัน" });
  for (let i = 0; i < 4; i++) {
    const yy = P.t + (i * (H - P.t - P.b)) / 3;
    svg.append(svgEl("line", { x1: P.l, x2: W - P.r, y1: yy, y2: yy, class: "grid" }));
    const t = svgEl("text", { x: P.l - 8, y: yy + 4, "text-anchor": "end", class: "lbl" }); t.textContent = fmtNum(max - (i * rng) / 3); svg.append(t);
  }
  const d = vals.map((v, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join("");
  svg.append(svgEl("path", { d: `${d}L${x(vals.length - 1)},${H - P.b}L${x(0)},${H - P.b}Z`, class: "area" }), svgEl("path", { d, class: "line", "vector-effect": "non-scaling-stroke" }));
  [[0, "start"], [vals.length - 1, "end"]].forEach(([i, anchor]) => { const t = svgEl("text", { x: x(i), y: H - 6, "text-anchor": anchor, class: "lbl" }); t.textContent = fmtDate(candles[i].time); svg.append(t); });
  const cross = svgEl("line", { y1: P.t, y2: H - P.b, class: "cross", visibility: "hidden" });
  const pt = svgEl("circle", { r: 5, class: "pt", visibility: "hidden" });
  svg.append(cross, pt);
  const tip = h("div", { class: "tip", hidden: true });
  const wrap = h("div", { class: "chart-wrap" }, svg, tip);
  const show = (e) => {
    const r = svg.getBoundingClientRect();
    const px = ((e.clientX - r.left) / r.width) * W;
    const i = Math.min(vals.length - 1, Math.max(0, Math.round(((px - P.l) / (W - P.l - P.r)) * (vals.length - 1))));
    cross.setAttribute("x1", x(i)); cross.setAttribute("x2", x(i)); pt.setAttribute("cx", x(i)); pt.setAttribute("cy", y(vals[i]));
    cross.setAttribute("visibility", "visible"); pt.setAttribute("visibility", "visible");
    tip.hidden = false; tip.textContent = `${fmtDate(candles[i].time)} · ${fmtMoney(vals[i], cur)}`; tip.style.left = Math.min(88, Math.max(12, (x(i) / W) * 100)) + "%";
  };
  const hide = () => { cross.setAttribute("visibility", "hidden"); pt.setAttribute("visibility", "hidden"); tip.hidden = true; };
  svg.addEventListener("pointermove", show); svg.addEventListener("pointerleave", hide);
  return wrap;
}

function exportCsv(symbol, candles) {
  if (!candles.length) return;
  const rows = [["date", "open", "high", "low", "close", "volume"], ...candles.map((c) => [new Date(c.time).toISOString().slice(0, 10), c.open, c.high, c.low, c.close, c.volume])];
  const csv = "﻿" + rows.map((r) => r.map((v) => `"${String(v ?? "").replace(/"/g, '""')}"`).join(",")).join("\r\n");
  const a = h("a", { href: URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" })), download: `${symbol}-history.csv` });
  document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

// ---------- watchlist, compare, alerts ----------
function renderWatchlist() {
  const root = $("#view-watchlist");
  const stamp = h("span", { class: "muted" });
  const tbody = h("tbody");
  const cmpHost = h("div");
  const alertsHost = h("div", { class: "stack" });

  const addInput = h("input", { class: "field", placeholder: "เพิ่ม Ticker เช่น AAPL", maxlength: "20", "aria-label": "Ticker ที่ต้องการติดตาม" });
  const addForm = h("form", { class: "row-form", onsubmit: (e) => {
    e.preventDefault(); const s = sanitize(addInput.value);
    if (!SYMBOL_RE.test(s)) return toast("Ticker ไม่ถูกต้อง");
    if (watchlist.includes(s)) return toast("มีหุ้นนี้ในรายการแล้ว");
    if (watchlist.length >= 20) return toast("ติดตามได้สูงสุด 20 หุ้น");
    watchlist = [...watchlist, s]; saveWatch(); addInput.value = ""; drawRows(); refreshQuotes();
  } }, addInput, h("button", { class: "btn primary", type: "submit" }, icon("plus"), "เพิ่ม"));

  let quotes = {};
  function drawRows() {
    if (!watchlist.length) { put(tbody, h("tr", {}, h("td", { colspan: "5" }, h("div", { class: "empty-note" }, "ยังไม่มีหุ้นที่ติดตาม เพิ่ม Ticker ด้านบน หรือกด “ติดตาม” ในหน้าหุ้น")))); return; }
    put(tbody, ...watchlist.map((s) => {
      const q = quotes[s];
      return h("tr", {},
        h("td", {}, h("a", { href: `#/stock/${encodeURIComponent(s)}` }, s)),
        h("td", {}, q ? fmtNum(q.price) : "…"),
        h("td", { class: dir(q?.change) }, q ? fmtPct(q.changePercent) : "…"),
        h("td", {}, h("button", { class: "btn small" + (compare.includes(s) ? " on" : ""), type: "button", "aria-pressed": String(compare.includes(s)), onclick: () => { if (compare.includes(s)) { compare = compare.filter((x) => x !== s); saveCompare(); drawRows(); drawCompare(); } else { addCompare(s); drawRows(); drawCompare(); } } }, icon("scale"), compare.includes(s) ? "เลือกแล้ว" : "เทียบ")),
        h("td", {}, h("button", { class: "btn small", type: "button", "aria-label": `ลบ ${s}`, onclick: () => { watchlist = watchlist.filter((x) => x !== s); saveWatch(); drawRows(); } }, "ลบ")));
    }));
  }
  async function refreshQuotes() {
    if (!watchlist.length) return;
    try { const d = await api(`/api/quotes?symbols=${watchlist.map(encodeURIComponent).join(",")}`); quotes = d.quotes; stamp.textContent = `อัปเดต ${new Date(d.asOf).toLocaleTimeString("th-TH")}`; drawRows(); }
    catch (e) { stamp.textContent = e.message; }
  }

  async function drawCompare() {
    if (compare.length < 2) {
      put(cmpHost, h("p", { class: "empty-note" }, compare.length ? `เลือก ${compare[0]} แล้ว เลือกอย่างน้อยอีก 1 ตัวเพื่อเปรียบเทียบ (สูงสุด 3)` : "กดปุ่ม “เทียบ” ที่หุ้นในรายการ หรือเพิ่มจากหน้าหุ้น (2–3 ตัว)"),
        compare.length ? h("div", { class: "chips mt" }, compare.map(chipRemove)) : null);
      return;
    }
    put(cmpHost, h("p", { class: "loading" }, "กำลังเปรียบเทียบ…"));
    try {
      const { rows } = await api(`/api/compare?symbols=${compare.join(",")}`);
      const M = (r, k) => r.metrics?.[k] ?? null;
      const spec = [
        ["ราคา", (r) => fmtMoney(r.quote?.price, r.currency), null],
        ["เปลี่ยนแปลงวันนี้", (r) => fmtPct(r.quote?.changePercent), (r) => r.quote?.changePercent, "max"],
        ["Market Cap", (r) => fmtCap(r.marketCapMillions), (r) => r.marketCapMillions, "max"],
        ["P/E (TTM)", (r) => fmtPlain(M(r, "peTTM"), "x"), (r) => (M(r, "peTTM") > 0 ? M(r, "peTTM") : null), "min"],
        ["ROE", (r) => fmtPlain(M(r, "roeTTM"), "%"), (r) => M(r, "roeTTM"), "max"],
        ["Net margin", (r) => fmtPlain(M(r, "netProfitMarginTTM"), "%"), (r) => M(r, "netProfitMarginTTM"), "max"],
        ["รายได้ YoY", (r) => fmtPlain(M(r, "revenueGrowthTTMYoy"), "%"), (r) => M(r, "revenueGrowthTTMYoy"), "max"],
        ["ปันผลต่อปี", (r) => fmtPlain(M(r, "dividendYieldIndicatedAnnual"), "%"), (r) => M(r, "dividendYieldIndicatedAnnual"), "max"],
        ["Beta", (r) => fmtPlain(M(r, "beta")), null],
        ["D/E", (r) => fmtPlain(M(r, "totalDebt/totalEquityQuarterly")), (r) => M(r, "totalDebt/totalEquityQuarterly"), "min"]
      ];
      put(cmpHost, h("div", { class: "tbl-scroll" }, h("table", { class: "t" },
        h("thead", {}, h("tr", {}, h("th", {}, ""), rows.map((r) => h("th", {}, h("a", { href: `#/stock/${encodeURIComponent(r.symbol)}` }, r.symbol), r.name ? ` · ${r.name}` : "")))),
        h("tbody", {}, spec.map(([label, fmt, pick, mode]) => {
          const scores = pick ? rows.map(pick).map((v) => (valid(v) ? v : null)) : [];
          const valid2 = scores.filter((v) => v !== null);
          const best = valid2.length > 1 && new Set(valid2).size > 1 ? (mode === "min" ? Math.min(...valid2) : Math.max(...valid2)) : null;
          return h("tr", {}, h("td", { class: "muted" }, label), rows.map((r, i) => h("td", { class: best !== null && scores[i] === best ? "best" : "" }, fmt(r))));
        })))),
        h("p", { class: "disc mt" }, "ตัวเลขสีเขียวคือค่าที่ดีกว่าในแถวนั้นเชิงตัวเลขเท่านั้น ต้องพิจารณาอุตสาหกรรมและบริบทประกอบ"));
    } catch (e) { put(cmpHost, errorBox(e.message, drawCompare)); }
  }
  const chipRemove = (s) => h("button", { class: "chip", type: "button", "aria-label": `เอา ${s} ออก`, onclick: () => { compare = compare.filter((x) => x !== s); saveCompare(); drawRows(); drawCompare(); } }, `${s} ×`);

  // alerts
  const aSym = h("input", { class: "field", placeholder: "Ticker", maxlength: "20", "aria-label": "Ticker สำหรับแจ้งเตือน" });
  const aDir = h("select", { class: "field", "aria-label": "เงื่อนไข" }, h("option", { value: "above" }, "ราคา ≥"), h("option", { value: "below" }, "ราคา ≤"));
  const aPrice = h("input", { class: "field", type: "number", step: "any", min: "0", placeholder: "ราคาเป้าหมาย", "aria-label": "ราคาเป้าหมาย" });
  function drawAlerts() {
    const perm = "Notification" in window && Notification.permission === "default";
    put(alertsHost, 
      h("form", { class: "row-form", onsubmit: (e) => { e.preventDefault(); if (createAlert(sanitize(aSym.value), aDir.value, Number(aPrice.value))) { aSym.value = aPrice.value = ""; drawAlerts(); pollAlerts(); } } },
        aSym, aDir, aPrice, h("button", { class: "btn primary", type: "submit" }, "ตั้งแจ้งเตือน")),
      perm && h("button", { class: "btn small", type: "button", onclick: async () => { await Notification.requestPermission(); drawAlerts(); } }, icon("bell"), "เปิดการแจ้งเตือนของเบราว์เซอร์"),
      alerts.length ? alerts.map((a) => h("div", { class: "alert-item" + (a.triggered ? " hit" : "") },
        h("span", {}, `${a.symbol} ${a.dir === "above" ? "≥" : "≤"} ${fmtNum(a.target, 4)} · ${a.triggered ? "ถึงเป้าหมายแล้ว" : "รอตรวจสอบ"}`),
        h("button", { class: "btn small", type: "button", onclick: () => { alerts = alerts.filter((x) => x.id !== a.id); saveAlerts(); drawAlerts(); } }, "ลบ")))
        : h("p", { class: "empty-note" }, "ยังไม่มีการแจ้งเตือน"),
      h("p", { class: "disc" }, "ระบบตรวจทุก 60 วินาทีขณะที่เปิดเว็บนี้ไว้ ไม่ใช่การแจ้งเตือนเบื้องหลัง"));
  }

  put(root, 
    h("div", { class: "page-title" }, h("h1", {}, "หุ้นที่ติดตาม"), h("span", { class: "row-form" }, stamp, h("button", { class: "btn small", type: "button", onclick: refreshQuotes }, icon("refresh"), "รีเฟรช"))),
    h("div", { class: "stack" },
      h("section", { class: "card" }, addForm, h("div", { class: "tbl-scroll mt" }, h("table", { class: "t" }, h("thead", {}, h("tr", {}, h("th", {}, "Ticker"), h("th", {}, "ราคา"), h("th", {}, "วันนี้"), h("th", {}, ""), h("th", {}, ""))), tbody))),
      h("section", { class: "card" }, h("h3", {}, "เปรียบเทียบหุ้น"), cmpHost),
      h("section", { class: "card" }, h("h3", {}, "แจ้งเตือนราคา"), alertsHost)));
  drawRows(); drawCompare(); drawAlerts(); refreshQuotes();
  every(60_000, refreshQuotes);
}

// ---------- alerts poller (runs on every page) ----------
async function pollAlerts() {
  const pending = alerts.filter((a) => !a.triggered);
  if (!pending.length) return;
  try {
    const symbols = [...new Set(pending.map((a) => a.symbol))].slice(0, 20);
    const { quotes } = await api(`/api/quotes?symbols=${symbols.join(",")}`);
    let changed = false;
    for (const a of pending) {
      const price = quotes[a.symbol]?.price;
      if (!valid(price)) continue;
      if (a.dir === "above" ? price >= a.target : price <= a.target) {
        a.triggered = true; changed = true;
        const msg = `${a.symbol} ${a.dir === "above" ? "สูงกว่า" : "ต่ำกว่า"} ${fmtNum(a.target, 4)} แล้ว (ราคา ${fmtNum(price)})`;
        toast("🔔 " + msg);
        if ("Notification" in window && Notification.permission === "granted") new Notification("StockLens AI", { body: msg });
      }
    }
    if (changed) { saveAlerts(); if (location.hash.startsWith("#/watchlist")) renderWatchlist(); }
  } catch { /* retried next minute */ }
}
setInterval(() => { if (!document.hidden) pollAlerts(); }, 60_000);

// ---------- copilot ----------
let chat = []; // {role:"user"|"model", text, err?}
let streaming = null; // AbortController while a reply is in progress

function md(text) {
  const frag = document.createDocumentFragment();
  const inline = (s) => s.split(/(\*\*[^*]+\*\*|`[^`]+`)/).filter(Boolean).map((p) =>
    p.startsWith("**") && p.endsWith("**") && p.length > 4 ? h("strong", {}, p.slice(2, -2)) : p.startsWith("`") && p.endsWith("`") && p.length > 2 ? h("code", {}, p.slice(1, -1)) : p);
  let list = null, listType = "", para = [];
  const flushPara = () => { if (para.length) { frag.append(h("p", {}, inline(para.join(" ")))); para = []; } };
  const flushList = () => { list = null; listType = ""; };
  for (const raw of text.split("\n")) {
    const line = raw.trimEnd();
    const bullet = line.match(/^\s*[-*•]\s+(.*)/), numbered = line.match(/^\s*\d+[.)]\s+(.*)/), heading = line.match(/^#{1,4}\s+(.*)/);
    if (bullet || numbered) {
      flushPara();
      const type = bullet ? "ul" : "ol";
      if (!list || listType !== type) { list = h(type, {}); listType = type; frag.append(list); }
      list.append(h("li", {}, inline((bullet || numbered)[1])));
    } else if (heading) { flushPara(); flushList(); frag.append(h("h4", {}, inline(heading[1]))); }
    else if (!line.trim()) { flushPara(); flushList(); }
    else { flushList(); para.push(line.trim()); }
  }
  flushPara();
  return frag;
}

function renderCopilot() {
  const root = $("#view-copilot");
  const log = h("div", { class: "chat-log", "aria-live": "polite" });
  const ctxChip = h("span");
  const tools = h("div", { class: "chat-tools" });
  const input = h("textarea", { rows: "1", maxlength: "1500", placeholder: "ถามเกี่ยวกับหุ้น งบการเงิน ตัวชี้วัด หรือความเสี่ยง…", "aria-label": "ข้อความถึง Co-Pilot" });
  const sendBtn = h("button", { class: "btn primary", type: "submit" }, icon("sparkles"), "ส่ง");

  const bubble = (m) => {
    const el = h("div", { class: `msg ${m.role}${m.err ? " err" : ""}` });
    if (m.role === "model" && !m.err) el.append(md(m.text));
    else el.textContent = m.text;
    return el;
  };
  function drawLog() {
    put(log, ...(chat.length ? chat.map(bubble) : [h("div", { class: "welcome" }, h("h2", {}, "Stock Co-Pilot"),
      h("p", {}, ctxSymbol ? `พร้อมคุยเรื่อง ${ctxSymbol} โดยใช้ราคา ตัวชี้วัด ผลประกอบการ และข่าวล่าสุดจาก Finnhub เป็นข้อมูลอ้างอิง` : "ถามเรื่องการอ่านงบ ตัวชี้วัด หรือเลือกหุ้นเพื่อให้ผมอ้างอิงข้อมูลจริงของหุ้นนั้น"),
      !health.gemini && h("p", { class: "down" }, "ยังไม่ได้ตั้งค่า GEMINI_API_KEY บนเซิร์ฟเวอร์"))]));
    log.scrollTop = log.scrollHeight;
  }
  function drawTools() {
    const prompts = ctxSymbol
      ? ["สรุปธุรกิจและผลประกอบการล่าสุด", "ความเสี่ยงหลักคืออะไร", "ตัวชี้วัดบอกอะไรเรื่องมูลค่า", "ข่าวล่าสุดมีผลอย่างไร"]
      : ["P/E คืออะไร ใช้ดูอย่างไร", "ROE ต่างจาก ROA อย่างไร", "เริ่มอ่านงบการเงินอย่างไร"];
    put(ctxChip, ctxSymbol ? h("button", { class: "chip", type: "button", title: "ล้างหุ้นที่เลือก", onclick: () => { ctxSymbol = ""; drawTools(); drawLog(); } }, `หุ้น: ${ctxSymbol} ×`) : h("span", { class: "pill" }, "ยังไม่ได้เลือกหุ้น (ค้นหาหุ้นแล้วกด “ถาม Co-Pilot”)"));
    put(tools, ...prompts.map((p) => h("button", { class: "chip", type: "button", onclick: () => ask(p) }, p)));
  }
  async function ask(text) {
    text = (text || "").trim();
    if (!text || streaming || !health.gemini) return health.gemini ? undefined : toast("ยังไม่ได้ตั้งค่า GEMINI_API_KEY");
    const history = chat.filter((m) => !m.err).map((m) => ({ role: m.role, text: m.text }));
    chat.push({ role: "user", text }); const reply = { role: "model", text: "" }; chat.push(reply);
    input.value = ""; input.style.height = "auto"; drawLog();
    const el = log.lastChild; el.classList.add("typing");
    streaming = new AbortController(); setSending(true);
    let frame = 0;
    const paint = () => { frame = 0; put(el, md(reply.text)); log.scrollTop = log.scrollHeight; };
    try {
      const response = await fetch("/api/copilot", { method: "POST", headers: { "Content-Type": "application/json" }, signal: streaming.signal, body: JSON.stringify({ message: text, symbol: ctxSymbol, history }) });
      if (!response.ok) { const d = await response.json().catch(() => ({})); throw new Error(d.error || `เกิดข้อผิดพลาด (${response.status})`); }
      const reader = response.body.getReader(), dec = new TextDecoder(); let buf = "";
      for (;;) {
        const { done, value } = await reader.read(); if (done) break;
        buf += dec.decode(value, { stream: true });
        let i;
        while ((i = buf.indexOf("\n\n")) !== -1) {
          const evt = buf.slice(0, i); buf = buf.slice(i + 2);
          if (!evt.startsWith("data:")) continue;
          const data = JSON.parse(evt.slice(5));
          if (data.t) { reply.text += data.t; if (!frame) frame = requestAnimationFrame(paint); }
          if (data.error) throw new Error(data.error);
        }
      }
    } catch (e) {
      if (e.name === "AbortError") { reply.text = reply.text || "(หยุดการตอบแล้ว)"; }
      else if (reply.text) reply.text += `\n\n⚠ ${e.message}`;
      else { reply.text = e.message || "ส่งคำถามไม่สำเร็จ"; reply.err = true; }
    } finally {
      cancelAnimationFrame(frame); streaming = null;
      if (document.body.contains(el)) { el.classList.remove("typing"); const fresh = bubble(reply); el.className = fresh.className; put(el, ...fresh.childNodes); }
      setSending(false);
    }
  }
  function setSending(on) {
    put(sendBtn, icon(on ? "stop" : "sparkles"), on ? "หยุด" : "ส่ง");
    sendBtn.type = on ? "button" : "submit"; sendBtn.onclick = on ? () => streaming?.abort() : null;
  }
  input.addEventListener("input", () => { input.style.height = "auto"; input.style.height = Math.min(150, input.scrollHeight) + "px"; });
  input.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); ask(input.value); } });

  put(root, 
    h("div", { class: "page-title" }, h("h1", {}, "Stock Co-Pilot"), h("span", { class: "row-form" }, ctxChip,
      h("button", { class: "btn small", type: "button", onclick: () => { streaming?.abort(); chat = []; drawLog(); } }, "ล้างแชต"))),
    h("section", { class: "card chat" }, log, tools, h("form", { class: "chat-form", onsubmit: (e) => { e.preventDefault(); ask(input.value); } }, input, sendBtn)),
    h("p", { class: "disc mt" }, `ขับเคลื่อนโดย Google Gemini${health.model ? ` (${health.model})` : ""} · อ้างอิงข้อมูลจาก Finnhub · AI อาจผิดพลาด ไม่ใช่คำแนะนำการลงทุน · อย่าใส่ข้อมูลส่วนตัวในแชต`));
  setSending(Boolean(streaming));
  drawTools(); drawLog();
}

// ---------- boot ----------
hydrateIcons();
(async function boot() {
  try { health = await api("/api/health"); } catch { /* status shows disconnected */ }
  renderStatus();
  route();
  pollAlerts();
})();
