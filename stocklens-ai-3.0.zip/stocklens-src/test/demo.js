// Runs the real app against mock Finnhub/Gemini so the UI can be previewed without API keys.
process.env.MOCK_CANDLES = "1";
const { listen, finnhubMock, geminiMock } = require("./mocks");
(async () => {
  const [fp, gp] = [await listen(finnhubMock), await listen(geminiMock)];
  Object.assign(process.env, {
    FINNHUB_API_KEY: "test-key", FINNHUB_BASE_URL: `http://127.0.0.1:${fp}`,
    GEMINI_API_KEY: "g-key", GEMINI_BASE_URL: `http://127.0.0.1:${gp}`, FINNHUB_CALLS_PER_MIN: "100000"
  });
  const app = require("../server");
  const port = Number(process.env.PORT || 3000);
  app.listen(port, () => console.log(`DEMO (mock data) at http://localhost:${port}`));
})();
