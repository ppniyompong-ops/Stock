// Integration smoke tests with mocked Finnhub + Gemini servers (no real network or keys needed).
const test = require("node:test");
const assert = require("node:assert/strict");
const http = require("node:http");

const { listen, finnhubMock, geminiMock } = require("./mocks");

let base, stop;
test.before(async () => {
  const [fp, gp] = [await listen(finnhubMock), await listen(geminiMock)];
  Object.assign(process.env, {
    FINNHUB_API_KEY: "test-key", FINNHUB_BASE_URL: `http://127.0.0.1:${fp}`,
    GEMINI_API_KEY: "g-key", GEMINI_BASE_URL: `http://127.0.0.1:${gp}`, FINNHUB_CALLS_PER_MIN: "1000"
  });
  const app = require("../server");
  const server = http.createServer(app);
  base = `http://127.0.0.1:${await listen(server)}`;
  stop = () => [server, finnhubMock, geminiMock].forEach((s) => s.close());
});
test.after(() => stop());

const json = async (path, init) => { const r = await fetch(base + path, init); return { status: r.status, body: await r.json() }; };
const post = (path, data) => json(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });

test("health reports configured providers", async () => {
  const { body } = await json("/api/health");
  assert.equal(body.finnhub, true);
  assert.equal(body.gemini, true);
});

test("stock snapshot aggregates Finnhub data and signals", async () => {
  const { status, body } = await json("/api/stock/aapl");
  assert.equal(status, 200);
  assert.equal(body.quote.price, 190.5);
  assert.equal(body.profile.name, "Apple Inc");
  assert.equal(body.metrics.peTTM, 31.2);
  assert.ok(body.signals.length >= 4);
  assert.deepEqual(body.peers, ["MSFT", "GOOG"]);
  assert.equal(body.nextEarnings.date, "2026-11-01");
  assert.equal(body.news.length, 1);
});

test("unknown ticker returns 404, invalid ticker 400", async () => {
  assert.equal((await json("/api/stock/NOPE")).status, 404);
  assert.equal((await json("/api/stock/bad%20sym!")).status, 400);
});

test("search puts US listings first", async () => {
  const { body } = await json("/api/search?q=apple");
  assert.equal(body.results[0].symbol, "AAPL");
});

test("market overview, batch quotes and compare", async () => {
  const market = await json("/api/market");
  assert.equal(market.body.indices.length, 4);
  assert.equal(market.body.status.isOpen, true);
  const quotes = await json("/api/quotes?symbols=AAPL,NOPE");
  assert.equal(quotes.body.quotes.AAPL.price, 190.5);
  assert.equal(quotes.body.quotes.NOPE, null);
  const cmp = await json("/api/compare?symbols=AAPL,MSFT");
  assert.equal(cmp.body.rows.length, 2);
  assert.equal((await json("/api/compare?symbols=A,B,C,D")).status, 400);
});

test("candles surface a plan error instead of crashing", async () => {
  const { status, body } = await json("/api/candles/AAPL");
  assert.equal(status, 403);
  assert.equal(body.code, "plan");
});

test("AI analysis returns parsed JSON (handles code fences) and caches", async () => {
  const first = await post("/api/ai/analyze", { symbol: "AAPL" });
  assert.equal(first.status, 200);
  assert.equal(first.body.analysis.summary, "ok");
  const second = await post("/api/ai/analyze", { symbol: "AAPL" });
  assert.equal(second.body.cached, true);
});

test("copilot streams SSE grounded with data and history", async () => {
  const r = await fetch(base + "/api/copilot", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message: "ความเสี่ยงคืออะไร", symbol: "AAPL", history: [{ role: "model", text: "drop me" }, { role: "user", text: "hi" }, { role: "model", text: "hello" }] })
  });
  assert.equal(r.status, 200);
  assert.match(r.headers.get("content-type"), /text\/event-stream/);
  const text = await r.text();
  const events = text.split("\n\n").filter(Boolean).map((e) => JSON.parse(e.replace(/^data: /, "")));
  const joined = events.filter((e) => e.t).map((e) => e.t).join("");
  assert.match(joined, /^สวัสดี turns=3 hasData=true$/);
  assert.equal(events.at(-1).done, true);
});

test("copilot validates input before streaming", async () => {
  assert.equal((await post("/api/copilot", { message: "" })).status, 400);
  assert.equal((await post("/api/copilot", { message: "x", symbol: "bad sym" })).status, 400);
});

test("CSP header is set and SPA fallback serves index", async () => {
  const r = await fetch(base + "/some/route");
  assert.match(r.headers.get("content-security-policy"), /script-src 'self'/);
});
