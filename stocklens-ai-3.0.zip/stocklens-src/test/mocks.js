// Mock Finnhub + Gemini servers used by tests and `npm run demo`.
const http = require("node:http");

function listen(server) {
  return new Promise((resolve) => server.listen(0, "127.0.0.1", () => resolve(server.address().port)));
}

const finnhubMock = http.createServer((req, res) => {
  const url = new URL(req.url, "http://x");
  const sym = url.searchParams.get("symbol");
  const send = (obj, status = 200) => { res.writeHead(status, { "Content-Type": "application/json" }); res.end(JSON.stringify(obj)); };
  if (req.headers["x-finnhub-token"] !== "test-key") return send({ error: "bad key" }, 401);
  switch (url.pathname) {
    case "/quote": return sym === "NOPE" ? send({ c: 0, d: null, dp: null, h: 0, l: 0, o: 0, pc: 0, t: 0 }) : send({ c: 190.5, d: 2.1, dp: 1.11, h: 191, l: 188, o: 189, pc: 188.4, t: 1_700_000_000 });
    case "/stock/profile2": return sym === "NOPE" ? send({}) : send({ name: "Apple Inc", exchange: "NASDAQ", finnhubIndustry: "Technology", country: "US", currency: "USD", marketCapitalization: 2_900_000, logo: "https://x/logo.png" });
    case "/stock/metric": return send({ metric: { peTTM: 31.2, roeTTM: 150, netProfitMarginTTM: 25, revenueGrowthTTMYoy: 2, "52WeekHigh": 199, "52WeekLow": 124, "totalDebt/totalEquityQuarterly": 1.8 } });
    case "/company-news": return send([{ headline: "Apple ships thing", source: "Reuters", url: "https://example.com/a", datetime: 1_700_000_000, summary: "s" }]);
    case "/stock/recommendation": return send([{ period: "2026-10-01", strongBuy: 10, buy: 20, hold: 8, sell: 1, strongSell: 0 }]);
    case "/stock/earnings": return send([{ period: "2026-06-30", actual: 1.4, estimate: 1.3, surprisePercent: 7.7 }]);
    case "/stock/peers": return send(["AAPL", "MSFT", "GOOG"]);
    case "/calendar/earnings": return send({ earningsCalendar: [{ date: "2026-11-01", epsEstimate: 1.5, hour: "amc" }] });
    case "/stock/market-status": return send({ isOpen: true, session: "regular" });
    case "/news": return send([{ headline: "Markets rally", source: "AP", url: "https://example.com/m", datetime: 1_700_000_000 }]);
    case "/search": return send({ result: [{ symbol: "AAPL.SW", displaySymbol: "AAPL.SW", description: "Apple SW", type: "Common Stock" }, { symbol: "AAPL", displaySymbol: "AAPL", description: "Apple Inc", type: "Common Stock" }] });
    case "/stock/candle": {
      if (!process.env.MOCK_CANDLES) return send({ error: "no access" }, 403);
      const n = 90, t0 = Math.floor(Date.now() / 1000) - n * 86400;
      const c = Array.from({ length: n }, (_, i) => +(170 + i * 0.22 + Math.sin(i / 4) * 5).toFixed(2));
      return send({ s: "ok", t: c.map((_, i) => t0 + i * 86400), o: c, h: c.map((v) => v + 1), l: c.map((v) => v - 1), c, v: c.map(() => 1_000_000) });
    }
    default: return send({ error: "nf" }, 404);
  }
});

const geminiMock = http.createServer((req, res) => {
  let body = "";
  req.on("data", (c) => (body += c));
  req.on("end", () => {
    if (req.headers["x-goog-api-key"] !== "g-key") { res.writeHead(403); return res.end("{}"); }
    const parsed = JSON.parse(body);
    if (req.url.includes(":streamGenerateContent")) {
      res.writeHead(200, { "Content-Type": "text/event-stream" });
      const lastText = parsed.contents.at(-1).parts[0].text;
      const turns = parsed.contents.length;
      const chunk = (t) => `data: ${JSON.stringify({ candidates: [{ content: { parts: [{ text: t }] } }] })}\r\n\r\n`;
      res.write(chunk("สวัสดี "));
      setTimeout(() => { res.write(chunk(`turns=${turns} hasData=${lastText.includes("Apple Inc")}`)); res.end(); }, 20);
    } else {
      const out = { summary: "ok", strengths: ["a"], risks: ["b"], valuation: "v", newsThemes: [], watch: ["w"] };
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ candidates: [{ content: { parts: [{ text: "```json\n" + JSON.stringify(out) + "\n```" }] } }] }));
    }
  });
});

module.exports = { listen, finnhubMock, geminiMock };
