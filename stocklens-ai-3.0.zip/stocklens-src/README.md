# StockLens AI 3.0

เว็บวิจัยหุ้นที่ใช้ **Finnhub** (ข้อมูลตลาด) + **Google Gemini** (AI) — Node.js + Express + HTML/CSS/JS ล้วน ไม่มี build step

## ฟีเจอร์
- **ภาพรวมตลาด**: ดัชนีหลักผ่าน ETF (SPY/QQQ/DIA/IWM), สถานะตลาดเปิด/ปิด, ข่าวตลาด
- **หน้าหุ้น**: ราคา, ช่วงราคาวัน/52 สัปดาห์, กราฟ (hover ดูราคา + ส่งออก CSV), ตัวชี้วัดแบ่งกลุ่ม, ความเห็นนักวิเคราะห์, EPS จริง vs คาดการณ์ + วันประกาศงบถัดไป, ข่าวบริษัท, หุ้นคู่เทียบ
- **บทวิเคราะห์ AI (Gemini)**: จุดแข็ง/ความเสี่ยง/มูลค่า/ธีมข่าว ในรูป JSON ที่ตรวจโครงสร้างแล้ว แคช 15 นาที
- **Stock Co-Pilot**: แชตแบบ streaming มีประวัติสนทนา และ **server ดึงข้อมูลจริงจาก Finnhub ป้อนให้ Gemini เอง** (ไม่ต้องเชื่อข้อความที่เบราว์เซอร์ส่งมา)
- **ติดตามหุ้น**: ราคาอัปเดตทุก 60 วินาที, เปรียบเทียบ 2–3 ตัว, แจ้งเตือนราคา (toast + Browser Notification ขณะเปิดหน้าเว็บ)
- ค้นหาแบบ autocomplete, กด `/` เพื่อโฟกัส, ธีมสว่าง/มืด, รองรับมือถือ

## รัน
```bash
cp .env.example .env     # ใส่ FINNHUB_API_KEY และ GEMINI_API_KEY
npm install
npm start                # http://localhost:3000
```
ลองดูหน้าตาโดยไม่ต้องมี key: `npm run demo` (ใช้ข้อมูลจำลอง) · ทดสอบ: `npm test`

## API (ภายใน)
| Endpoint | หน้าที่ |
|---|---|
| `GET /api/health` | สถานะการตั้งค่า key (ไม่เปิดเผยค่า key) |
| `GET /api/market` | ดัชนี ETF + สถานะตลาด + ข่าว |
| `GET /api/search?q=` | ค้นหา (เรียงหุ้น US ขึ้นก่อน) |
| `GET /api/stock/:symbol` | ข้อมูลรวมทั้งหน้าในคำขอเดียว |
| `GET /api/quotes?symbols=A,B` | ราคาหลายตัว (สูงสุด 20) |
| `GET /api/compare?symbols=A,B,C` | ข้อมูลเปรียบเทียบ (สูงสุด 3) |
| `GET /api/candles/:symbol?days=` | ราคาปิดย้อนหลัง |
| `POST /api/ai/analyze` | บทวิเคราะห์ Gemini `{symbol}` |
| `POST /api/copilot` | แชต streaming (SSE) `{message, symbol, history}` |

## ข้อควรรู้
- **กราฟย้อนหลัง**: endpoint `/stock/candle` ของ Finnhub ต้องใช้แผนเสียเงิน แผนฟรีจะได้ 403 — เว็บแสดงข้อความอธิบายและยังมีแถบช่วงราคา 52 สัปดาห์ให้ดู
- **หุ้นไทย**: Finnhub แผนฟรีเน้นตลาดสหรัฐ หุ้นไทย (เช่น `PTT.BK`) ส่วนมากไม่รองรับ จึงเอาออกจากปุ่มลัด
- **โควตา**: server มีแคชตามชนิดข้อมูล, รวมคำขอซ้ำ, และจำกัด 55 calls/นาทีให้ไม่เกินโควตา Finnhub ฟรี (60/นาที) การเปิดหุ้นใหม่หนึ่งตัวใช้ ~8 calls
- **ความปลอดภัย**: key อยู่ฝั่ง server เท่านั้น (Finnhub ส่งผ่าน header, Gemini ผ่าน `x-goog-api-key`), มี CSP, rate limit ต่อ IP, ตรวจ input ทุก endpoint, ข้อความข่าวถูกกำชับให้ Gemini ถือเป็นข้อมูลไม่ใช่คำสั่ง
- ข้อมูลในเบราว์เซอร์ (รายการติดตาม แจ้งเตือน ธีม) เก็บใน localStorage ของเครื่องนั้นเท่านั้น แจ้งเตือนทำงานเฉพาะตอนเปิดหน้าเว็บ
- **ไม่ใช่คำแนะนำการลงทุน** AI อาจผิดพลาด

## Deploy บน Render
Build: `npm install --omit=dev` · Start: `npm start` · ตั้ง `FINNHUB_API_KEY` และ `GEMINI_API_KEY` ใน Environment (มี `render.yaml` ให้แล้ว)

> ถ้าเคยวาง API key ลงในแชตหรือภาพหน้าจอ ให้สร้าง key ใหม่แล้วยกเลิกอันเก่า
