# StockLens AI — MVP

Thai/US stock research dashboard built with Node.js, Express, HTML/CSS/JS, Finnhub, and optional SEC Company Facts endpoint.

## Security first
The Finnhub API key shared in chat/image is exposed. Regenerate it in Finnhub before use. Never paste the key into `public/` files or commit `.env` to GitHub.

## Run locally
1. Install Node.js 18+ (20 recommended).
2. Copy `.env.example` to `.env`.
3. Put your NEW Finnhub key in `FINNHUB_API_KEY`.
4. Set `SEC_USER_AGENT` to an app name and a real contact email.
5. Run:
   ```bash
   npm install
   npm start
   ```
6. Open http://localhost:3000

## Endpoints
- `GET /api/health`
- `GET /api/search?q=AAPL`
- `GET /api/quote/AAPL`
- `GET /api/profile/AAPL`
- `GET /api/metrics/AAPL`
- `GET /api/analysis/AAPL` — rule-based notes, not an LLM
- `GET /api/sec/company-facts/320193` — SEC Company Facts for CIK 0000320193 (Apple)

## Thai tickers
Finnhub coverage depends on the product/plan and exchange symbol conventions. For Thai listed companies, test the symbol format supported by your Finnhub plan (for example, `PTT.BK` may not be supported). Do not silently show US data as Thai data. For a production Thai market data feed, check SET data licensing and provider coverage.

## Data and licensing
- Finnhub API limits and available endpoints depend on plan.
- SEC data covers registrants that file with SEC; it is not a Thai-stock financial-data source.
- This project does not guarantee real-time quotes. Always show source/timestamp and check data licensing before public redistribution.
- yfinance is intentionally not wired into the production server: it is an unofficial Python library and should be used only after reviewing its terms and the relevant Yahoo Finance terms. If added, host it as a separate Python service and cache results.

## Render deployment
1. Push project to GitHub (do not commit `.env`).
2. Create a Render Web Service from the repository.
3. Build command: `npm install`; Start command: `npm start`.
4. Add `FINNHUB_API_KEY` and `SEC_USER_AGENT` in Render Environment.
5. Add `GEMINI_API_KEY` in Render Environment to enable Stock Co-Pilot. Optional: set `GEMINI_MODEL` (default `gemini-2.5-flash`).
6. Deploy and test `/api/health`.

## Stock Co-Pilot
- `POST /api/copilot` accepts `{ "message": "...", "symbol": "AAPL", "context": "..." }`.
- Calls Google Gemini server-side; the browser never receives the API key.
- Chat endpoint has input limits, timeout, and a small in-memory per-IP usage limit. Free-tier quotas can still be exhausted.
- If Gemini is not configured, chat displays a clear configuration error instead of fake answers.

## Current limitations
- No authentication or user-specific watchlist UI yet.
- No PostgreSQL runtime integration yet; `schema.sql` is a foundation for the next phase.
- The `/api/analysis/:symbol` notes remain rule-based; Stock Co-Pilot is the separate Gemini LLM chat. Neither gives guaranteed predictions or personal buy/sell advice.
- No licensed Thai market feed yet.

## StockLens AI 2.0 — workspace features

- Responsive research dashboard with light/dark theme preference.
- Personal watchlist saved in the current browser (up to 12 tickers).
- Side-by-side comparison for up to 3 tickers using quote and metric endpoints.
- Local price alerts (checked when the dashboard is opened; not push notifications and not guaranteed real-time).
- Position/return calculator with no-fee estimate.
- Historical daily close chart for 1, 3, 6, or 12 months and CSV export.
- Historical prices use the Finnhub stock-candle endpoint; availability depends on Finnhub plan and ticker coverage.

### Deploy when the GitHub repository contains only the ZIP

If the ZIP is stored at the repository root as `stocklens-ai-complete.zip`, set Render Build Command to:

```sh
unzip -o stocklens-ai-complete.zip -d . && npm install
```

Set Start Command to `npm start`. If you later upload the extracted source files directly to the repository root, use `npm install` as Build Command instead.

### Important limitations

The current analysis panel is transparent, rule-based metric commentary, not a generative AI model. Watchlist, comparison list, theme and alerts are stored in browser local storage on that device only. Price alerts are checked on page load, not continuously in the background. Data availability, latency and API limits depend on Finnhub. The SEC endpoint only applies to eligible US filers. No PostgreSQL persistence is wired into this MVP yet.
