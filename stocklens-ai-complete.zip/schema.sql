-- Optional persistence schema for future features.
CREATE TABLE IF NOT EXISTS stock_searches (
  id BIGSERIAL PRIMARY KEY,
  symbol VARCHAR(24) NOT NULL,
  searched_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_stock_searches_symbol ON stock_searches(symbol);
CREATE INDEX IF NOT EXISTS idx_stock_searches_searched_at ON stock_searches(searched_at DESC);

CREATE TABLE IF NOT EXISTS stock_watchlist (
  id BIGSERIAL PRIMARY KEY,
  user_id VARCHAR(128) NOT NULL,
  symbol VARCHAR(24) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, symbol)
);
