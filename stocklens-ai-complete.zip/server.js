require("dotenv").config();

const express = require("express");
const helmet = require("helmet");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "100kb" }));
app.use(express.static(path.join(__dirname, "public")));

const SYMBOL_RE = /^[A-Z0-9.^-]{1,20}$/;
const cache = new Map();
const CACHE_TTL_MS = 60_000;

function validSymbol(value) {
  return typeof value === "string" && SYMBOL_RE.test(value.trim().toUpperCase());
}

function cached(key) {
  const item = cache.get(key);
  if (!item || Date.now() - item.savedAt > CACHE_TTL_MS) {
    cache.delete(key);
    return null;
  }
  return item.value;
}

function setCache(key, value) {
  cache.set(key, { value, savedAt: Date.now() });
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "StockLens AI", timestamp: new Date().toISOString() });
});

app.get("/api/search", async (req, res) => {
  const q = String(req.query.q || "").trim();
  if (q.length < 1 || q.length > 60) {
    return res.status(400).json({ error: "กรุณาพิมพ์ชื่อหุ้นหรือ Ticker" });
  }

  const cacheKey = `search:${q.toLowerCase()}`;
  const saved = cached(cacheKey);
  if (saved) return res.json(saved);

  // Finnhub symbol search works best for US symbols; Thai coverage depends on plan/provider.
  if (!process.env.FINNHUB_API_KEY) {
    return res.status(503).json({
      error: "ยังไม่ได้ตั้งค่า Finnhub API Key",
      hint: "คัดลอก .env.example เป็น .env แล้วใส่ API key ใหม่ที่ Finnhub"
    });
  }

  try {
    const url = new URL("https://finnhub.io/api/v1/search");
    url.searchParams.set("q", q);
    url.searchParams.set("token", process.env.FINNHUB_API_KEY);
    const response = await fetch(url, { signal: AbortSignal.timeout(10000) });
    if (!response.ok) {
      return res.status(response.status === 429 ? 429 : 502).json({
        error: response.status === 429
          ? "Finnhub rate limit เต็ม กรุณารอสักครู่"
          : "ค้นหาหุ้นผ่าน Finnhub ไม่สำเร็จ"
      });
    }
    const payload = await response.json();
    const results = (payload.result || []).slice(0, 12).map(x => ({
      symbol: x.displaySymbol || x.symbol,
      description: x.description || "",
      type: x.type || ""
    }));
    const result = { results, source: "Finnhub" };
    setCache(cacheKey, result);
    res.json(result);
  } catch (error) {
    console.error("Search error:", error.message);
    res.status(502).json({ error: "เชื่อมต่อ Finnhub ไม่สำเร็จ" });
  }
});

app.get("/api/quote/:symbol", async (req, res) => {
  const symbol = String(req.params.symbol || "").trim().toUpperCase();
  if (!validSymbol(symbol)) return res.status(400).json({ error: "Ticker ไม่ถูกต้อง" });
  const key = process.env.FINNHUB_API_KEY;
  if (!key) return res.status(503).json({ error: "ยังไม่ได้ตั้งค่า Finnhub API Key" });

  const cacheKey = `quote:${symbol}`;
  const saved = cached(cacheKey);
  if (saved) return res.json(saved);

  try {
    const url = new URL("https://finnhub.io/api/v1/quote");
    url.searchParams.set("symbol", symbol);
    url.searchParams.set("token", key);
    const response = await fetch(url, { signal: AbortSignal.timeout(10000) });
    if (!response.ok) {
      return res.status(response.status === 429 ? 429 : 502).json({
        error: response.status === 429 ? "Finnhub rate limit เต็ม" : "ดึงราคาหุ้นไม่สำเร็จ"
      });
    }
    const q = await response.json();
    if (!q || (!q.c && !q.pc)) {
      return res.status(404).json({
        error: "ไม่พบราคาสำหรับ Ticker นี้ หรือแผน API ไม่รองรับตลาดดังกล่าว",
        symbol
      });
    }
    const result = {
      symbol,
      price: q.c,
      change: q.d,
      changePercent: q.dp,
      high: q.h,
      low: q.l,
      open: q.o,
      previousClose: q.pc,
      timestamp: q.t ? new Date(q.t * 1000).toISOString() : null,
      source: "Finnhub",
      note: "ความล่าช้าและความครอบคลุมของข้อมูลขึ้นอยู่กับตลาดและแพ็กเกจ API"
    };
    setCache(cacheKey, result);
    res.json(result);
  } catch (error) {
    console.error("Quote error:", error.message);
    res.status(502).json({ error: "เชื่อมต่อ Finnhub ไม่สำเร็จ" });
  }
});

app.get("/api/profile/:symbol", async (req, res) => {
  const symbol = String(req.params.symbol || "").trim().toUpperCase();
  if (!validSymbol(symbol)) return res.status(400).json({ error: "Ticker ไม่ถูกต้อง" });
  const key = process.env.FINNHUB_API_KEY;
  if (!key) return res.status(503).json({ error: "ยังไม่ได้ตั้งค่า Finnhub API Key" });

  const cacheKey = `profile:${symbol}`;
  const saved = cached(cacheKey);
  if (saved) return res.json(saved);

  try {
    const url = new URL("https://finnhub.io/api/v1/stock/profile2");
    url.searchParams.set("symbol", symbol);
    url.searchParams.set("token", key);
    const response = await fetch(url, { signal: AbortSignal.timeout(10000) });
    if (!response.ok) return res.status(502).json({ error: "ดึงข้อมูลบริษัทไม่สำเร็จ" });
    const p = await response.json();
    if (!p || !p.name) return res.status(404).json({ error: "ไม่พบข้อมูลบริษัท", symbol });
    const result = {
      symbol,
      name: p.name,
      country: p.country,
      currency: p.currency,
      exchange: p.exchange,
      industry: p.finnhubIndustry,
      marketCapitalization: p.marketCapitalization,
      shareOutstanding: p.shareOutstanding,
      weburl: p.weburl,
      logo: p.logo,
      source: "Finnhub"
    };
    setCache(cacheKey, result);
    res.json(result);
  } catch (error) {
    console.error("Profile error:", error.message);
    res.status(502).json({ error: "เชื่อมต่อ Finnhub ไม่สำเร็จ" });
  }
});

app.get("/api/metrics/:symbol", async (req, res) => {
  const symbol = String(req.params.symbol || "").trim().toUpperCase();
  if (!validSymbol(symbol)) return res.status(400).json({ error: "Ticker ไม่ถูกต้อง" });
  const key = process.env.FINNHUB_API_KEY;
  if (!key) return res.status(503).json({ error: "ยังไม่ได้ตั้งค่า Finnhub API Key" });

  const cacheKey = `metrics:${symbol}`;
  const saved = cached(cacheKey);
  if (saved) return res.json(saved);

  try {
    const url = new URL("https://finnhub.io/api/v1/stock/metric");
    url.searchParams.set("symbol", symbol);
    url.searchParams.set("metric", "all");
    url.searchParams.set("token", key);
    const response = await fetch(url, { signal: AbortSignal.timeout(10000) });
    if (!response.ok) return res.status(502).json({ error: "ดึงตัวชี้วัดไม่สำเร็จ" });
    const payload = await response.json();
    const m = payload.metric || {};
    const result = {
      symbol,
      peTTM: m.peTTM ?? null,
      pbQuarterly: m.pbQuarterly ?? null,
      roeTTM: m.roeTTM ?? null,
      roaTTM: m.roaTTM ?? null,
      netProfitMarginTTM: m.netProfitMarginTTM ?? null,
      revenueGrowthTTMYoy: m.revenueGrowthTTMYoy ?? null,
      epsTTM: m.epsTTM ?? null,
      dividendYieldIndicatedAnnual: m.dividendYieldIndicatedAnnual ?? null,
      source: "Finnhub",
      note: "ตัวชี้วัดอาจไม่มีครบทุกหุ้นและขึ้นกับแพ็กเกจ"
    };
    setCache(cacheKey, result);
    res.json(result);
  } catch (error) {
    console.error("Metrics error:", error.message);
    res.status(502).json({ error: "เชื่อมต่อ Finnhub ไม่สำเร็จ" });
  }
});

app.get("/api/sec/company-facts/:cik", async (req, res) => {
  const cik = String(req.params.cik || "").replace(/\D/g, "").padStart(10, "0");
  if (!/^\d{10}$/.test(cik)) return res.status(400).json({ error: "CIK ไม่ถูกต้อง" });
  const userAgent = process.env.SEC_USER_AGENT;
  if (!userAgent || userAgent.includes("your-email@example.com")) {
    return res.status(503).json({ error: "กรุณาตั้ง SEC_USER_AGENT ใน .env เป็นชื่อแอปและอีเมลติดต่อจริง" });
  }
  try {
    const response = await fetch(`https://data.sec.gov/api/xbrl/companyfacts/CIK${cik}.json`, {
      headers: { "User-Agent": userAgent, "Accept-Encoding": "gzip, deflate" },
      signal: AbortSignal.timeout(15000)
    });
    if (!response.ok) return res.status(502).json({ error: "SEC API request failed", status: response.status });
    const facts = await response.json();
    res.json({
      cik,
      entityName: facts.entityName,
      taxonomyAvailable: Object.keys(facts.facts || {}),
      facts: facts.facts || {},
      source: "SEC EDGAR Company Facts",
      note: "ข้อมูลนี้สำหรับบริษัทที่รายงานต่อ SEC และไม่ได้แทนข้อมูลหุ้นไทย"
    });
  } catch (error) {
    console.error("SEC error:", error.message);
    res.status(502).json({ error: "เชื่อมต่อ SEC ไม่สำเร็จ" });
  }
});

// Basic rule-based summary: transparent, not investment advice, and not an LLM.
app.get("/api/analysis/:symbol", async (req, res) => {
  const symbol = String(req.params.symbol || "").trim().toUpperCase();
  if (!validSymbol(symbol)) return res.status(400).json({ error: "Ticker ไม่ถูกต้อง" });
  if (!process.env.FINNHUB_API_KEY) return res.status(503).json({ error: "ยังไม่ได้ตั้งค่า Finnhub API Key" });

  try {
    const url = new URL("https://finnhub.io/api/v1/stock/metric");
    url.searchParams.set("symbol", symbol);
    url.searchParams.set("metric", "all");
    url.searchParams.set("token", process.env.FINNHUB_API_KEY);
    const response = await fetch(url, { signal: AbortSignal.timeout(10000) });
    if (!response.ok) return res.status(502).json({ error: "ไม่สามารถดึงข้อมูลเพื่อวิเคราะห์ได้" });
    const payload = await response.json();
    const m = payload.metric || {};
    const observations = [];
    if (Number.isFinite(m.peTTM)) observations.push(m.peTTM > 30
      ? "P/E สูงกว่า 30 เท่า: ควรตรวจสอบว่าการเติบโตของกำไรรองรับมูลค่าหรือไม่"
      : m.peTTM > 0 ? "P/E อยู่ที่ " + m.peTTM.toFixed(2) + " เท่า; ควรเปรียบเทียบกับคู่แข่งในอุตสาหกรรม"
      : "P/E ติดลบหรือไม่พร้อมใช้งาน จึงไม่ควรใช้ P/E แบบทั่วไปในการประเมิน");
    if (Number.isFinite(m.roeTTM)) observations.push("ROE: " + m.roeTTM.toFixed(2) + "%; ตรวจสอบแนวโน้มหลายปีและระดับหนี้ประกอบ");
    if (Number.isFinite(m.netProfitMarginTTM)) observations.push("อัตรากำไรสุทธิ: " + m.netProfitMarginTTM.toFixed(2) + "%");
    if (Number.isFinite(m.revenueGrowthTTMYoy)) observations.push("การเติบโตของรายได้ YoY: " + m.revenueGrowthTTMYoy.toFixed(2) + "%");
    if (!observations.length) observations.push("ข้อมูลตัวชี้วัดไม่เพียงพอสำหรับสรุป โปรดลองหุ้นอื่นหรือตรวจสอบสิทธิ์ API");
    res.json({
      symbol,
      observations,
      type: "rule-based",
      source: "Finnhub metrics",
      disclaimer: "เป็นการสรุปจากตัวชี้วัดที่มี ไม่ใช่คำแนะนำซื้อขาย และไม่ใช่การวิเคราะห์โดย LLM"
    });
  } catch (error) {
    console.error("Analysis error:", error.message);
    res.status(502).json({ error: "เชื่อมต่อ Finnhub ไม่สำเร็จ" });
  }
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`StockLens AI running at http://localhost:${PORT}`);
});
