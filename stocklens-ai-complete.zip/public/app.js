const $ = (id) => document.getElementById(id);
const form = $("search-form");
const input = $("symbol-input");
const resultsBox = $("search-results");
const stockSection = $("stock-section");
let toastTimer;

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 3500);
}
function fmt(value, suffix = "", digits = 2) {
  if (value === null || value === undefined || value === "" || !Number.isFinite(Number(value))) return "ไม่มีข้อมูล";
  return Number(value).toLocaleString("en-US", { maximumFractionDigits: digits, minimumFractionDigits: 0 }) + suffix;
}
function money(value, currency = "USD") {
  if (value === null || value === undefined || !Number.isFinite(Number(value)) || Number(value) === 0) return "ไม่มีข้อมูล";
  try { return new Intl.NumberFormat("en-US", { style: "currency", currency, maximumFractionDigits: 2 }).format(value); }
  catch { return fmt(value); }
}
async function api(url) {
  const response = await fetch(url);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
function showResults(items) {
  resultsBox.innerHTML = "";
  if (!items.length) {
    resultsBox.innerHTML = '<div class="result-item">ไม่พบผลลัพธ์ ลองค้นหาด้วย Ticker โดยตรง</div>';
  } else {
    for (const item of items) {
      const button = document.createElement("button");
      button.className = "result-item";
      const left = document.createElement("span");
      const strong = document.createElement("strong");
      strong.textContent = item.symbol || "";
      const small = document.createElement("small");
      small.textContent = item.description || "";
      left.append(strong, document.createElement("br"), small);
      const right = document.createElement("small");
      right.textContent = item.type || "Equity";
      button.append(left, right);
      button.addEventListener("click", () => loadStock(item.symbol));
      resultsBox.append(button);
    }
  }
  resultsBox.classList.remove("hidden");
}
form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const q = input.value.trim();
  if (!q) return toast("กรุณาพิมพ์ชื่อหุ้นหรือ Ticker");
  resultsBox.classList.remove("hidden");
  resultsBox.textContent = "กำลังค้นหา...";
  try {
    const data = await api(`/api/search?q=${encodeURIComponent(q)}`);
    // If the exact ticker is not in search results, still try it directly.
    const items = data.results || [];
    if (!items.some(x => x.symbol.toUpperCase() === q.toUpperCase())) {
      items.unshift({ symbol: q.toUpperCase(), description: "ลองเปิด Ticker นี้โดยตรง", type: "Symbol" });
    }
    showResults(items);
  } catch (error) {
    showResults([{ symbol: q.toUpperCase(), description: "ลองเปิด Ticker โดยตรง", type: "Symbol" }]);
    toast(error.message);
  }
});
document.querySelectorAll("[data-symbol]").forEach(button => {
  button.addEventListener("click", () => loadStock(button.dataset.symbol));
});

async function loadStock(rawSymbol) {
  const symbol = String(rawSymbol || "").trim().toUpperCase();
  if (!symbol) return;
  input.value = symbol;
  stockSection.classList.remove("hidden");
  resultsBox.classList.add("hidden");
  $("stock-symbol").textContent = symbol;
  $("company-name").textContent = "กำลังโหลดข้อมูล...";
  $("company-meta").textContent = "กำลังเชื่อมต่อ Finnhub";
  $("analysis").innerHTML = '<p class="muted">กำลังวิเคราะห์ตัวชี้วัด...</p>';
  stockSection.scrollIntoView({ behavior: "smooth", block: "start" });

  const [quoteR, profileR, metricsR, analysisR] = await Promise.allSettled([
    api(`/api/quote/${encodeURIComponent(symbol)}`),
    api(`/api/profile/${encodeURIComponent(symbol)}`),
    api(`/api/metrics/${encodeURIComponent(symbol)}`),
    api(`/api/analysis/${encodeURIComponent(symbol)}`)
  ]);
  const quote = quoteR.status === "fulfilled" ? quoteR.value : null;
  const profile = profileR.status === "fulfilled" ? profileR.value : null;
  const metrics = metricsR.status === "fulfilled" ? metricsR.value : null;
  const analysis = analysisR.status === "fulfilled" ? analysisR.value : null;

  $("company-name").textContent = profile?.name || symbol;
  $("company-meta").textContent = [profile?.exchange, profile?.industry, profile?.country].filter(Boolean).join(" · ") || "ข้อมูลบริษัทไม่มีในแผน API หรือไม่รองรับ Ticker นี้";
  $("price").textContent = quote ? money(quote.price, profile?.currency || "USD") : "ไม่มีข้อมูล";
  const change = quote?.changePercent;
  $("price-change").textContent = quote ? `${fmt(quote.change)} (${fmt(change, "%")}) · Finnhub` : (quoteR.reason?.message || "ไม่สามารถดึงราคาได้");
  $("price-change").style.color = Number(change) >= 0 ? "var(--green)" : "var(--red)";
  $("market-cap").textContent = profile?.marketCapitalization ? fmt(profile.marketCapitalization) : "ไม่มีข้อมูล";
  $("pe").textContent = fmt(metrics?.peTTM, "x");
  $("roe").textContent = fmt(metrics?.roeTTM, "%");
  $("roa").textContent = fmt(metrics?.roaTTM, "%");
  $("margin").textContent = fmt(metrics?.netProfitMarginTTM, "%");
  $("growth").textContent = fmt(metrics?.revenueGrowthTTMYoy, "%");
  $("eps").textContent = fmt(metrics?.epsTTM);
  $("dividend").textContent = fmt(metrics?.dividendYieldIndicatedAnnual, "%");

  const analysisBox = $("analysis");
  analysisBox.innerHTML = "";
  if (analysis?.observations?.length) {
    analysis.observations.forEach(text => {
      const p = document.createElement("p");
      p.className = "observation";
      p.textContent = text;
      analysisBox.append(p);
    });
  } else {
    const p = document.createElement("p");
    p.textContent = analysisR.status === "rejected" ? analysisR.reason.message : "ยังไม่มีข้อมูลเพียงพอสำหรับสรุป";
    analysisBox.append(p);
  }
  $("data-note").querySelector("span").textContent =
    `แหล่งข้อมูล: Finnhub · เวลาดึงข้อมูล ${new Date().toLocaleString()} · ราคาและตัวชี้วัดอาจล่าช้า/ไม่ครบตามแผน API`;
  if (!quote && !profile && !metrics) toast("โหลดข้อมูลไม่สำเร็จ: ตรวจ API Key, สิทธิ์แผน และ Ticker");
}
if (window.lucide) window.lucide.createIcons();
